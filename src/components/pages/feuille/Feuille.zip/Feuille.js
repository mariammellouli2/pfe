import React, { useState, useEffect } from "react";
import { DataGrid } from "@mui/x-data-grid";
import {
  Toolbar,
  IconButton,
  Typography,
  Select,
  MenuItem,
  Box,
  Tabs,
  Tab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  useTheme,
  TextField,
  DialogContentText,
} from "@mui/material";
import { Save, Send, Delete, Add } from "@mui/icons-material";
import KeyboardDoubleArrowLeftIcon from "@mui/icons-material/KeyboardDoubleArrowLeft";
import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";
import { rows } from "./data";
import { Snackbar } from "@mui/material";
import InfoTwoToneIcon from "@mui/icons-material/InfoTwoTone";
import { grey } from "@mui/material/colors";
import { format, addDays, startOfWeek, addWeeks } from "date-fns";
import { fr } from "date-fns/locale";
import { useNavigate } from "react-router-dom";
import { useMsal } from "@azure/msal-react";
import axios from 'axios';

const currentDate = new Date();
const days = Array.from({ length: 7 }, (_, i) => addDays(currentDate, i));

const Feuille = () => {
  const { instance } = useMsal();
  const navigate = useNavigate();

  const [remark, setRemark] = useState("");
  const theme = useTheme();
  const [openAttachmentDialog, setOpenAttachmentDialog] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [userName, setUserName] = useState("");
  const [currentTime, setCurrentTime] = useState("");
  const [dataRows, setDataRows] = useState(rows);
  const [openDialog, setOpenDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedTab, setSelectedTab] = useState(0);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [openAddTaskDialog, setOpenAddTaskDialog] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState("");
  const [openManualTaskDialog, setOpenManualTaskDialog] = useState(false);

  const [weekStart, setWeekStart] = useState(new Date());
  const [currentWeekStart, setCurrentWeekStart] = useState(
    startOfWeek(new Date(), { weekStartsOn: 1 })
  );

  const fetchData = async () => {
    setLoading(true);
    try {
      const accounts = instance.getAllAccounts();
      if (accounts.length > 0) {
        const email = accounts[0].username; 
        const response = await axios.get(`https://localhost:5177/api/WorkItem/byemail?email=${email}`);
        const data = response.data;
        console.log(data);
        const hasUniqueIds = data.every((item) => item.id !== undefined && item.id !== null);
        if (!hasUniqueIds) {
          return;
        }
        setDataRows(data);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    calculateTotalGlobal();
  }, [dataRows]);


  const weekdays = Array.from({ length: 7 }, (_, i) =>
    addDays(weekStart, i)
  ).filter((day) => day.getDay() !== 0 && day.getDay() !== 6);
  const dayLabels = weekdays.map((day) =>
    format(day, "EEEE dd", { locale: fr })
  );
  const [taskDetails, setTaskDetails] = useState({
    Projet: "",
    Prestation: "",
    Durée_estimée: "",
    Client: "",
    Pieces_jointes: "",
  });

  useEffect(() => {
    setUserName("Admin");
    const intervalId = setInterval(() => {
      const currentTime = new Date().toLocaleTimeString();
      setCurrentTime(currentTime);
    }, 1000);
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    localStorage.setItem("feuilleDataRows", JSON.stringify(dataRows));
  }, [dataRows]);

  const currentDate = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const [totalGlobal, setTotalGlobal] = useState(0);

  const handlePreviousWeek = () => {
    setWeekStart((currentWeekStart) => addWeeks(currentWeekStart, -1));
  };

  const handleNextWeek = () => {
    setWeekStart((currentWeekStart) => addWeeks(currentWeekStart, 1));
  };

  useEffect(() => {
    // Calculer le total global lors du chargement initial
    calculateTotalGlobal();
  }, []);

  useEffect(() => {
    // Calculer le total global à chaque modification des lignes de données
    calculateTotalGlobal();
  }, [dataRows]);

  const calculateTotal1 = (row) => {
    return (
      parseFloat(row.Lundi || 0) +
      parseFloat(row.Mardi || 0) +
      parseFloat(row.Mercredi || 0) +
      parseFloat(row.Jeudi || 0) +
      parseFloat(row.Vendredi || 0)
    );
  };

  const calculateTotalGlobal = () => {
    const total = dataRows.reduce((acc, row) => acc + calculateTotal1(row), 0);
    setTotalGlobal(total);
    return total;
  };

  <span style={{ fontWeight: "bold", marginRight: "20px" }}>
    Total Global: {totalGlobal}
  </span>;

  const handlePrestationChange = (event, id) => {
    const { value } = event.target;
    const updatedRows = dataRows.map((row) => {
      if (row.id === id) {
        return { ...row, Type_prestation: value };
      }
      return row;
    });
    setDataRows(updatedRows);
  };

  const handleHourChange = (event, id, day) => {
    const { value } = event.target;
    if (parseFloat(value) >= 0 || value === "") {
      const updatedRows = dataRows.map((row) => {
        if (row.id === id) {
          const newData = { ...row, [day]: value };
          const total1 = calculateTotal1(newData);
          return { ...newData, Total1: total1 };
        }
        return row;
      });
      setDataRows(updatedRows);
    }
  };

  const handleTaskDetailsChange = (event) => {
    const { name, value } = event.target;
    setTaskDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value,
    }));
  };
  const handleStatusChange = (event, id) => {
    const { value } = event.target;
    const updatedRows = dataRows.map((row) => {
      if (row.id === id) {
        let backgroundColor = theme.palette.error.main;
        if (value === "En cours") {
          backgroundColor = theme.palette.warning.main;
        } else if (value === "Terminé") {
          backgroundColor = theme.palette.success.main;
        }
        return { ...row, Statut: value, backgroundColor };
      }
      return row;
    });
    setDataRows(updatedRows);
  };
  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  const handleAddRow = () => {
    const newRowId = dataRows.length + 1;
    const newRow = {
      Projet: "",
      Client: "",
      Prestation: "",
      Source: "",
      Type_prestation: "Non Facturable",
      Statut: "Non commencé",
      Temps_estimer: "",
      Total1: "",
      Lundi: "",
      Mardi: "",
      Mercredi: "",
      Jeudi: "",
      Vendredi: "",
    };
    setDataRows([...dataRows, newRow]);
  };

  const handleAddTask = (id) => {
    const updatedRows = dataRows.map((row) => {
      if (row.id === id) {
        const taskCount = row.taches ? row.taches.length : 0;
        const newTask = "Tâche ${taskCount + 1}";
        const updatedTaches = row.taches ? [...row.taches, newTask] : [newTask];
        return { ...row, taches: updatedTaches };
      }
      return row;
    });
    setDataRows(updatedRows);
  };

  const handleOpenAddTaskDialog = () => {
    setOpenAddTaskDialog(true);
  };

  const handleCloseAddTaskDialog = () => {
    setOpenAddTaskDialog(false);
  };

  const handleOpenManualTaskDialog = () => {
    setOpenManualTaskDialog(true);
  };

  const handleCloseManualTaskDialog = () => {
    setOpenManualTaskDialog(false);
  };
  const handleOpenAttachmentDialog = () => {
    setOpenAttachmentDialog(true);
  };

  const handleCloseAttachmentDialog = () => {
    setOpenAttachmentDialog(false);
  };

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleAddAttachment = () => {
    console.log("Fichier sélectionné :", selectedFile);
    setSelectedFile(null);
    handleCloseAttachmentDialog();
  };

  const handleMethodSelect = (method) => {
    setSelectedMethod(method);
    setOpenAddTaskDialog(false);
    if (method === "saisie") {
      handleOpenManualTaskDialog();
    }
  };
  const showSuccessSnackbar = () => {
    setShowSuccessMessage(true);
    setTimeout(() => {
      setShowSuccessMessage(false);
    }, 3000);
  };

  const handleDeleteTimesheet = () => {
    console.log("Suppression de la timesheet...");
    showSuccessSnackbar();
  };

  const handleSendTimesheet = () => {
    console.log("Envoi de la timesheet...");
    showSuccessSnackbar();
  };

  const handleSaveTimesheet = () => {
    console.log("Enregistrement de la timesheet...");
    showSuccessSnackbar();
  };

  const handleFacturableChange = (event, id) => {
    const { value } = event.target;
    const updatedRows = dataRows.map((row) => {
      if (row.id === id) {
        return { ...row, Facturable: value };
      }
      return row;
    });
    setDataRows(updatedRows);
  };
  const handleAddTaskManually = () => {
    const newTask = {
      id: dataRows.length + 1,
      Projet: taskDetails.Projet,
      Prestation: taskDetails.Prestation,
      Durée_estimée: taskDetails.Durée_estimée,
      Client: taskDetails.Client,
      Pieces_jointes: taskDetails.Pieces_jointes,
      Facturable: taskDetails.Facturable,
    };
    setDataRows((prevRows) => [...prevRows, newTask]);
    handleCloseManualTaskDialog();
    setTaskDetails({
      Projet: "",
      Prestation: "",
      Durée_estimée: "",
      Client: "",
      Pieces_jointes: "",
      Facturable: "Non Facturable",
    });
  };

  const columns = [
    {
      field: "belongTo",
      headerName: "Projet",
      width: 150,
      align: "center",
      headerAlign: "center",
      renderCell: (params) => (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Typography>{params.value}</Typography>
          {params.row.taches &&
            params.row.taches.map((task) => (
              <Typography key={task}>{task}</Typography>
            ))}
          {params.row.attachment && (
            <a
              href={params.row.attachment}
              target="_blank"
              rel="noopener noreferrer"
            >
              {params.row.attachment}
            </a>
          )}
        </div>
      ),
    },
    {
      field: "clientName",
      headerName: "Client",
      align: "center",
      headerAlign: "center",
    },
    {
      field: "titleDevops",
      headerName: "Titre DevOps",
      align: "center",
      headerAlign: "center",
    },
    {
      field: "descriptionDevops",
      headerName: "Prestation",
      width: 100,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "workItemType",
      headerName: "Type prestation",
      width: 100,
      align: "center",
      headerAlign: "center",
    },
    { field: "source",
     headerName: "Source", 
     width: 90, align: "center",
      headerAlign: "center",
       valueGetter: (params) => "devops" },
    {
      field: "Type",
      headerName: "Type prestation",
      width: 150,
      align: "center",
      headerAlign: "center",
      renderCell: (params) => (
        <Select
        value={params.value || 'Non Facturable'}
        onChange={(event) => handlePrestationChange(event, params.row.id)}
        style={{ width: "100%" }}
      >
        <MenuItem value="Non Facturable">Non Facturable</MenuItem>
        <MenuItem value="Facturable">Facturable</MenuItem>
      </Select>
      
      ),
    },
    {
      field: "state",
      headerName: "Statut",
      width: 150,
      editable: true,
      renderCell: (params) => (
        <Select
          value={params.value}
          onChange={(e) => handleStatusChange(e, params.row.id)}
          fullWidth
        >
          <MenuItem value="New">Nouveau</MenuItem>
          <MenuItem value="To Do">À faire</MenuItem>
          <MenuItem value="Doing">En cours</MenuItem>
          <MenuItem value="Terminated">Terminé</MenuItem>
          <MenuItem value="Removed">Supprimé</MenuItem>
        </Select>
      ),
    },
    {
      field: "originalEstimate",
      headerName: "Estimer",
      width: 80,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "total1",
      headerName: "Total1",
      width: 100,
      align: "center",
      headerAlign: "center",
      valueFormatter: (params) => `${params.value} `,
    },
    {
      field: "back",
      headerName: (
        <IconButton style={{ color: "black" }} onClick={handlePreviousWeek}>
          <KeyboardDoubleArrowLeftIcon />
        </IconButton>
      ),
      width: 80,
      sortable: false,
    },
  ];

  weekdays.forEach((day) => {
    columns.push({
      field: day.toLocaleDateString("en-US", { weekday: "short" }),
      headerName: format(day, "EEE.dd", { locale: fr }),
      width: 160,
      align: "center",
      headerAlign: "center",
      renderCell: (params) => (
        <>
          <input
            type="number"
            value={params.value}
            onChange={(event) => handleHourChange(event, params.row.id, day)}
            style={{ width: "100%" }}
          />
          <IconButton
            onClick={handleOpenAttachmentDialog}
            style={{ color: grey[500] }}
          >
            <InfoTwoToneIcon />
          </IconButton>
          <Dialog
            open={openAttachmentDialog}
            onClose={handleCloseAttachmentDialog}
            PaperProps={{
              elevation: 0,
            }}
          >
            <DialogTitle>Pieces jointes</DialogTitle>
            <DialogContent>
              <TextField
                fullWidth
                placeholder="Ajouter le chemin de la pièce jointe"
                variant="outlined"
              />
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseAttachmentDialog}>Annuler</Button>
              <Button onClick={handleAddAttachment}>Ajouter</Button>
            </DialogActions>
          </Dialog>
        </>
      ),
    });
  });

  columns.push({
    field: "next",
    headerName: (
      <IconButton onClick={handleNextWeek} style={{ color: "black" }}>
        <KeyboardDoubleArrowRightIcon />
      </IconButton>
    ),
    width: 100,
    sortable: false,
  });

  const handleAttachments = (id) => {
    // Implement logic to handle adding attachments here
    console.log("Adding attachments for row with ID:", id);
  };

  const handleFileUpload = (event, id) => {
    const file = event.target.files[0];
    const fileName = file.name;
    // Logic to save the file URL or name to the corresponding row
    const updatedRows = dataRows.map((row) => {
      if (row.id === id) {
        return { ...row, attachment: fileName }; // Change 'attachment' to the appropriate field name
      }
      return row;
    });
    setDataRows(updatedRows);
  };

  const globalTotal1 = dataRows.reduce(
    (acc, row) => acc + calculateTotal1(row),
    0
  );

  return (
    <>
    <div>
      <Typography variant="h6" align="center" style={{ marginBottom: "20px" }}>
        Time Sheet - {userName} - {currentDate} - {currentTime}
      </Typography>
      <Snackbar
        open={showSuccessMessage}
        message="Opération réussie !"
        autoHideDuration={3000} // Disparaît après 3 secondes
        onClose={() => setShowSuccessMessage(false)}
      />
      <div style={{ height: "calc(100vh - 250px)", width: "100%" }}>
        <DataGrid
          rows={dataRows}
          columns={columns}
          pageSize={10}
          checkboxSelection
          components={{
            Toolbar: () => (
              <Toolbar>
                <IconButton color="primary" onClick={handleSaveTimesheet}>
                  <Save style={{ color: "#494A4A" }} />
                </IconButton>
                <IconButton color="primary" onClick={handleSendTimesheet}>
                  <Send style={{ color: "#494A4A" }} />
                </IconButton>
                <IconButton color="secondary" onClick={handleDeleteTimesheet}>
                  <Delete style={{ color: "#f44336" }} />
                </IconButton>
                <div style={{ flex: 1 }} />
                <span style={{ fontWeight: "bold", marginRight: "20px" }}>
                  Total Global: {globalTotal1}
                </span>
                <IconButton color="primary" onClick={handleOpenAddTaskDialog}>
                  <Add />
                </IconButton>
              </Toolbar>
            ),
          }}
        />
      </div>
      <Dialog open={openAddTaskDialog} onClose={handleCloseAddTaskDialog}>
        <DialogTitle>Ajouter une tâche</DialogTitle>
        <DialogContent>
          <Tabs value={selectedTab} onChange={handleTabChange} centered>
            <Tab label="Saisie manuelle" />
            <Tab label="Utiliser des données prédéfinies" />
          </Tabs>
          {selectedTab === 0 && (
            <div>
              {/* Contenu de la tab "Saisie manuelle" */}
              <TextField
                margin="dense"
                label="Projet"
                fullWidth
                name="Projet"
                value={taskDetails.Projet}
                onChange={handleTaskDetailsChange}
              />
              <TextField
                margin="dense"
                label="Prestation"
                fullWidth
                name="Prestation"
                value={taskDetails.Prestation}
                onChange={handleTaskDetailsChange}
              />
              <TextField
                margin="dense"
                label="Durée estimée"
                fullWidth
                name="Durée_estimée"
                value={taskDetails.Durée_estimée}
                onChange={handleTaskDetailsChange}
              />
              <TextField
                margin="dense"
                label="Client"
                fullWidth
                name="Client"
                value={taskDetails.Client}
                onChange={handleTaskDetailsChange}
              />
              <TextField
                margin="dense"
                label="Statut"
                fullWidth
                name="Statut"
                value={taskDetails.Prestation}
                onChange={handleTaskDetailsChange}
              />
              <TextField
                margin="dense"
                label="Source"
                fullWidth
                name="Source"
                value={taskDetails.Prestation}
                onChange={handleTaskDetailsChange}
              />
              {/* Autres champs à remplir pour la saisie manuelle */}
            </div>
          )}
          {selectedTab === 1 && (
            <div>
              {/* Contenu de la tab "Utiliser des données prédéfinies" */}
              <Select
                value={taskDetails.Prestation}
                onChange={handleTaskDetailsChange}
                fullWidth
              >
                <MenuItem value="donnees1">Donnée prédéfinie 1</MenuItem>
                <MenuItem value="donnees2">Donnée prédéfinie 2</MenuItem>
                {/* Autres options de données prédéfinies */}
              </Select>
              {/* Autres champs à remplir pour les données prédéfinies */}
            </div>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Annuler</Button>
          <Button onClick={handleAddTaskManually} color="primary">
            Ajouter
          </Button>
        </DialogActions>
      </Dialog>
      </div>
    </>
  );
};

export default Feuille;
